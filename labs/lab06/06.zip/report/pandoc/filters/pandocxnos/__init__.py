"""Package initialization."""

from .core import *
from .main import main
from .pandocattributes import PandocAttributes
